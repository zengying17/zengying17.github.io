# Ying Zeng

Assistant Professor of Economics, Xiamen University (WISE)

- Faculty page: https://faculty.xmu.edu.cn/yingzeng/en/index.htm
- Bilibili (teaching videos): https://space.bilibili.com/2015836889
