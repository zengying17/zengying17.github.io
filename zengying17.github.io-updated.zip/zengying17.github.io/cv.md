---
layout: page
title: CV
permalink: /cv/
---

[Download CV (PDF)]({{ "/assets/cv.pdf" | relative_url }})

<embed src="{{ '/assets/cv.pdf' | relative_url }}" type="application/pdf" width="100%" height="900px" />
