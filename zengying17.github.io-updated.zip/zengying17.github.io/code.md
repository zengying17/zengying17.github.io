---
layout: page
title: Code
permalink: /code/
---

## ate_pct (Stata & R)

Implements estimation and inference for average treatment effects in
percentage points under treatment effect heterogeneity.

### Stata
Stable version available from SSC:
```stata
ssc install ate_pct
```
